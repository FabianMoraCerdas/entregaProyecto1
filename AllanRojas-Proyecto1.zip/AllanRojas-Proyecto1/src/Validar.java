/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sebas
 */

import java.util.Hashtable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validar {
    // Tabla hash que contiene las palabras reservadas de Python
    private static Hashtable<String, Boolean> palabrasReservadas = new Hashtable<>();

    // Inicializar la tabla hash con las palabras reservadas
    static {
        String[] reservadas = {
            "False", "None", "True", "and", "as", "assert", "async", "await", "break", 
            "class", "continue", "def", "del", "elif", "else", "except", "finally", 
            "for", "from", "global", "if", "import", "in", "is", "lambda", 
            "nonlocal", "not", "or", "pass", "raise", "return", "try", 
            "while", "with", "yield"
        };
        for (String palabra : reservadas) {
            palabrasReservadas.put(palabra, true);
        }
    }

    /**
     * Método para validar identificadores en Python.
     * Un identificador válido debe:
     * - Comenzar con una letra o guion bajo (_)
     * - No usar palabras reservadas de Python
     * - Puede contener letras, dígitos y guiones bajos después del primer carácter
     * @param identificador El identificador a validar
     * @return true si el identificador es válido, false si no lo es
     */
    public static boolean validarIdentificador(String identificador) {
        // Verificar si el identificador es una palabra reservada
        if (palabrasReservadas.containsKey(identificador)) {
            return false;  // Es una palabra reservada, por lo tanto, no es un identificador válido
        }

        // Regex para verificar que el identificador comienza con una letra o guion bajo
        Pattern pattern = Pattern.compile("^[a-zA-Z_][a-zA-Z0-9_]*$");
        Matcher matcher = pattern.matcher(identificador);
        return matcher.matches();  // Retorna true si es un identificador válido
    }

    /**
     * Método para validar la sintaxis correcta de la función input() en Python.
     * Debe cumplir la estructura: variable = input("mensaje")
     * @param linea La línea de código a validar
     * @return true si la función input está correctamente estructurada, false si no
     */
    public static boolean validarInput(String linea) {
        // Expresión regular para validar la estructura del input()
        String regex = "^[a-zA-Z_][a-zA-Z0-9_]*\\s*=\\s*input\\(\".*\"\\)\\s*$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(linea.trim());
        return matcher.matches();  // Retorna true si la línea está correctamente estructurada
    }
}
