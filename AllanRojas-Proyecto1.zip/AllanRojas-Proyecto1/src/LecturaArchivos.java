/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sebas
*/

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class LecturaArchivos {
    private String pyFileName;  // Nombre del archivo Python
    private List<String> errores = new ArrayList<>();  // Lista de errores para el resumen final

    public LecturaArchivos(String pyFileName) {
        this.pyFileName = pyFileName;
    }

    public void procesarArchivo() {
        File pyFile = new File(pyFileName);  // Archivo Python a leer

        // Verifica que el archivo exista y tenga la extensión .py
        if (!pyFile.exists() || !pyFileName.endsWith(".py")) {
            System.out.println("El archivo proporcionado no es válido o no es un archivo .py.");
            return;
        }

        // Nombre del archivo .log que se generará
        String logFileName = pyFileName.replace(".py", "-errores.log");
        ClaseRegistroErrores logGenerator = new ClaseRegistroErrores(logFileName);  // Crear instancia de ClaseRegistroErrores

        try (BufferedReader reader = new BufferedReader(new FileReader(pyFile))) {
            String line;
            int lineNumber = 1;  // Contador de líneas
            int comentarioCount = 0;  // Contador de comentarios
            int[] tokenCounts = new int[6];  // Contador de tokens para comparación

            boolean importFound = false;  // Verifica si se encontró el primer import

            while ((line = reader.readLine()) != null) {
                // Escribe la línea original en el archivo .log, manteniendo el formato original
                logGenerator.escribirLinea(lineNumber, line);

                // 1. Verificar la posición del import
                if (line.contains("import")) {
                    if (!importFound && lineNumber > 1) {  // Si se encuentra un import en una línea que no es la primera
                        String error = "Error 200. Línea " + lineNumber + ". El import no está al inicio del código.";
                        errores.add(error);  // Agregar error a la lista
                    }
                    importFound = true;  // Marcamos que se encontró un import
                }

                // 2. Contabilizar comentarios
                if (line.trim().startsWith("#")) {
                    comentarioCount++;
                }

                // 3. Contabilizar operadores de comparación
                if (line.contains("==")) tokenCounts[0]++;
                if (line.contains("!=")) tokenCounts[1]++;
                if (line.contains("<=")) tokenCounts[2]++;
                if (line.contains(">=")) tokenCounts[3]++;
                if (line.contains("<") && !line.contains("<=")) tokenCounts[4]++;
                if (line.contains(">") && !line.contains(">=")) tokenCounts[5]++;

                // **Nuevo ajuste**: Ignorar llamadas a funciones como print(), input(), etc.
                if (line.contains("print(") || line.contains("input(")) {
                    lineNumber++;
                    continue;  // Ignoramos las líneas con estas funciones
                }

                // **Ignorar condiciones "if" completamente**
                if (line.trim().startsWith("if")) {
                    lineNumber++;
                    continue;  // Ignoramos las líneas que contienen condiciones "if"
                }

                // 4. Validar identificadores solo en asignaciones simples
                if (line.contains("=")) {
                    String[] partes = line.split("=");
                    String identificador = partes[0].trim();

                    // **Nuevo ajuste**: Validar asignaciones múltiples (e.g., "fila, columna = ...")
                    if (identificador.contains(",")) {
                        String[] multiplesIdentificadores = identificador.split(",");
                        for (String id : multiplesIdentificadores) {
                            id = id.trim();
                            if (!Validar.validarIdentificador(id)) {
                                String error = "Error 300. Línea " + lineNumber + ". Identificador no válido: " + id;
                                errores.add(error);  // Agregar error a la lista
                            }
                        }
                    } else {
                        // Validar solo identificadores simples (que no son expresiones)
                        if (!identificador.contains("(") && !identificador.contains("[") && !identificador.contains(".")) {
                            if (!Validar.validarIdentificador(identificador)) {
                                String error = "Error 300. Línea " + lineNumber + ". Identificador no válido: " + identificador;
                                errores.add(error);  // Agregar error a la lista
                            }
                        }
                    }
                }

                lineNumber++;  // Incrementa el contador de línea
            }

            // Mostrar todos los errores al final
            if (!errores.isEmpty()) {
                logGenerator.escribirErroresAlFinal(errores);  // Escribir la lista de errores al final
            }

            // Mostrar la cantidad de tokens de comparación después de los errores
            logGenerator.escribirTokens(tokenCounts);

            // Mostrar la cantidad de comentarios al final del todo
            logGenerator.escribirComentariosFinal(comentarioCount);

        } catch (IOException e) {
            System.out.println("Error procesando el archivo: " + e.getMessage());
        }
    }
}

