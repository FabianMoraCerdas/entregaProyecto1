/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sebas
 */
public class Principal {
    public static void main(String[] args) {
        // Verifica que se haya pasado un archivo como argumento
        if (args.length < 1) {
            System.out.println("Por favor, proporciona el nombre del archivo .py.");
            return;
        }

        String pyFileName = args[0];  // Nombre del archivo .py
        LecturaArchivos fileReader = new LecturaArchivos(pyFileName);  // Crear instancia de LecturaArchivos
        fileReader.procesarArchivo();  // Procesar el archivo
    }
}
